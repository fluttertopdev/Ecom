@extends('admin.layouts.app')
@section('content')




<div class="container mt-4">
<div class="card">
<div class="card-header">
    <div class="row">
        <div class="col-md-6">
            <h5>Sellers Payout</h5>
        </div>
        
    </div>
</div>
<div class="card-body">
    <div class="table-responsive text-nowrap">
        <table class="table">
            <thead class="table-light">
                <tr class="text-nowrap">
                    <th>ID</th>
                    <th>Sellers Name</th>
                    <th>Date</th>
                    <th>Amount</th>
                  
                   
                
                </tr>
            </thead>
            <tbody>
            
                <tr>
                    <td>1</td>
             


                   
                  
                    <td>test business11</td>

                      <td>21-09-2024</td>
                      <td>20000</td>
                  
                 
               
                
                  
                
                </tr>
             
              
            </tbody>
        </table>
    </div>
</div>

</div>
</div>



@endsection