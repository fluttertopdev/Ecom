@extends('website.layout.app')
@section('content')

    <main class="main">
     
      <section class="section-box shop-template mt-30">
        <div class="container">
          <div class="row">
            <div class="col-lg-10 mx-auto page-content">
              <h2 class="text-center mb-20">Term and Condition</h2>

              <p><?php echo $cms_data->des?></p> 
            
            </div>
          </div>
        </div>
      </section>
     
     
    </main>
 @endsection
